const express = require("express");
const path = require("path");

const app = express();
const PORT = 3000;

// Tell Express to serve static files from the "public" folder
app.use(express.static(path.join(__dirname, "public")));

// Simple test route (for proof)
app.get("/test", (req, res) => {
  res.send("Express is working!");
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
